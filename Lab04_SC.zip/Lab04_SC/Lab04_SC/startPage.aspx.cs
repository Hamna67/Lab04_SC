﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab04_SC
{
    public partial class startPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void AdminButton_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/admin.aspx");
        }

        protected void UserButton_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/UserForm.aspx");
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

namespace Lab04_SC
{
    public partial class UserForm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void SubmitButton_Click(object sender, EventArgs e)
        {
            //getting data entered by user
            string reg = RegTextBox.Text;
            string name = NameTextBox.Text;
            string degree = DegreeTextBox.Text;
            string cl = ClassTextBox.Text;
            string section = SectionTextBox.Text;

            string result = "Form submitted successfully!"; ;


            //making connection with database
            MySqlConnection cnn;
            string connetionString = null;
            connetionString = "server=localhost;database=userinfo;port=3307;user id=root;password=deutrium2;";
            cnn = new MySqlConnection(connetionString);

            //query for login
            //string query1 = "select * from cafe.user where UserName='" + name + "' and Password = '" + password + "' and Position = '" + position + "';";

            string query1 = "insert into userinfo.User(RegNumber,Name,Degree,Class,Section) values('"+reg+"','"+name+"','"+degree+"','"+cl+"','"+section+"');";
            try
            {
                MySqlCommand MyCommand1 = new MySqlCommand(query1, cnn);      
                MySqlDataReader MyReader1;

                cnn.Open();
                MyReader1 = MyCommand1.ExecuteReader();     // Here our query will be executed and data saved into the database.  


                while (MyReader1.Read())
                {
                    result = "Form submitted successfully!";
 
                }

                cnn.Close();
            }
            catch (Exception ex)
            {

                result = "Reg Number already in use!";
            }

            Label7.Text = result;

        }
    }
}
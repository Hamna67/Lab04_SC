﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
namespace Lab04_SC
{
    public partial class admin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //getting data entered by user
            string name = NameTextBox.Text;
            string password = PasswordTextBox.Text;
           

            string result = "User not authenticated!";


            //making connection with database
            MySqlConnection cnn;
            string connetionString = null;
            connetionString = "server=localhost;database=userinfo;port=3307;user id=root;password=deutrium2;";
            cnn = new MySqlConnection(connetionString);

            //query for login
            //string query1 = "select * from cafe.user where UserName='" + name + "' and Password = '" + password + "' and Position = '" + position + "';";

            string query1 = "select * from userinfo.admin where Name= '" + name + "' AND Password = '" + password + "';";
            try
            {
                MySqlCommand MyCommand1 = new MySqlCommand(query1, cnn);
                MySqlDataReader MyReader1;

                cnn.Open();
                MyReader1 = MyCommand1.ExecuteReader();     // Here our query will be executed and data saved into the database.  


                while (MyReader1.Read())
                {
                    result = "User authenticated!";
               

                    Response.Redirect("~/Retrieve.aspx");
                }

                cnn.Close();
            }
            catch (Exception ex)
            {

                result = "User not authenticated!";
            }

            Label4.Text = result;
        }
    }
}